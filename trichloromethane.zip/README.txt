Malware name: trichloromethane.exe
type: GDI-Trojan.Win32
Damage rate: Destructive Very damaging and corrupts MBR until windows is reinstalled
Damage rate: safety there 0% Damage with the safety version
Made in: C++
Creator: prgbquad-370
Creation date: May 30 2026

This is very dangerous for the non-safety version! It will destroy this computer by overwriting MBR and disable keyboard and mouse input
The Creator is NOT responsible for any damages!